package com.dicoding.tapembelajaranbiologi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class RegistrasiActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registrasi);
    }
}
